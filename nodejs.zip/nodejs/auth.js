var ids = {
  oracle: {
    "ClientId": "ad450857a39b476b95b87664cc3fc887",
    "ClientSecret": "b9b71544-361a-408f-9f58-706f4617e1a9",
	"ClientTenant": "idcs-91cb2fc4bb6e4067b075db399ed83581",
    "IDCSHost": "https://%tenant%.identity.oraclecloud.com",
    "AudienceServiceUrl" : "https://idcs-91cb2fc4bb6e4067b075db399ed83581.identity.oraclecloud.com",
    "TokenIssuer": "https://identity.oraclecloud.com/",
    "scope": "urn:opc:idm:t.user.me openid",
    "logoutSufix": "/oauth2/v1/userlogout",
    "redirectURL": "http://localhost:3000/callback"
  }
};

module.exports = ids;
